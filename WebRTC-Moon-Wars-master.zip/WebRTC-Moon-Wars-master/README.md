# WebRTC-Moon-Wars


To play,
1. Clone the repository.
2. Open app.js and change channel_name in line_number 10 to something which you feel is unique.
3. Open index.html in two separate windows and start playing.
